function ordena(n1, n2, n3, n4, n5) {
    var numeros = [n1, n2, n3, n4, n5];
    numeros.sort(function(a, b) {
        return b - a;
    });
    return numeros;
}
console.log(ordena(2, 6, 4, 9, 7));