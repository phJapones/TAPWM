function validaridade(idade) {
    return idade >= 7 && idade <= 17;
}

function criarobjeto() {
    event.preventDefault();
    var nome = document.getElementById("nome").value;
    var nascimento = document.getElementById("nascimento").value;
    var inscricao = document.querySelector('input[name="inscricao"]:checked').value;
    var endereco = document.getElementById("endereco").value;
    var idade = new Date().getFullYear() - new Date(nascimento).getFullYear();

    if (validaridade(idade) && inscricao === "sim") {
        var aluno = {
            nome: nome,
            nascimento: nascimento,
            inscrito: inscricao,
            endereco: endereco
        };
        alert("Nome da pessoa  " + aluno.nome + "\n" + "  Data Nascimento  " + aluno.nascimento + "\n" + "  Endereço  " + aluno.endereco + "\n" + "  Está inscrito no torneio");
        } else {
            alert("Nome da pessoa  " + nome + "\n" + "  Data Nascimento  " + nascimento + "\n" + "  Endereço  " + endereco + "\n" + "  Não está inscrito no torneio porque não atende aos requisitos");
        }
}