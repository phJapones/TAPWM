function procura(texto) {
    let contador = 0
    for(let i = 0; i <texto.length; i++){
        if (texto[i].toLowerCase() === "a"){
            contador++
        }
        else if(texto[i].toUpperCase() === "A"){
            contador++
        }
    }
    console.log(`Quantidade de 'A': ${contador}`); 
}


//exemplo
let textoEx = "A nós bastem nossos próprios ais,Que a ninguém sua cruz é pequenina.Por pior que seja a situação da China,Os nossos calos doem muito mais...";procura(textoEx)